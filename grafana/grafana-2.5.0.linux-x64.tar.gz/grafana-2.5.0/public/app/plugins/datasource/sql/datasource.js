/*! grafana - v2.5.0 - 2015-10-28
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache-2.0 */

define(["angular","lodash","kbn"],function(a){"use strict";var b=a.module("grafana.services");b.factory("SqlDatasource",function(){function a(){}return a})});