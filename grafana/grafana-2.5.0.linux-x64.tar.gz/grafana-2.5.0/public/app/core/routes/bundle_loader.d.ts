/// <reference path="../../../../public/app/headers/require/require.d.ts" />
export declare class BundleLoader {
    lazy: any;
    loadingDefer: any;
    constructor(bundleName: any);
}
