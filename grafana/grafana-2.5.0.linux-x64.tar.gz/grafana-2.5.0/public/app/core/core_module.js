/*! grafana - v2.5.0 - 2015-10-28
 * Copyright (c) 2015 Torkel Ödegaard; Licensed Apache-2.0 */

define(["require","exports","angular"],function(a,b,c){return c.module("grafana.core",["ngRoute"])});