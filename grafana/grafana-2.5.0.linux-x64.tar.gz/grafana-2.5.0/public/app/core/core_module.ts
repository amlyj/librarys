///<reference path="../headers/common.d.ts" />

import angular = require('angular');

export = angular.module('grafana.core', ['ngRoute']);
