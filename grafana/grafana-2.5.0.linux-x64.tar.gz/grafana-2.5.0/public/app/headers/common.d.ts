///<reference path="require/require.d.ts" />
///<reference path="angularjs/angularjs.d.ts" />
///<reference path="lodash/lodash.d.ts" />
///<reference path="moment/moment.d.ts" />

// dummy modules
declare module 'config' {
  var config : any;
  export = config;
}

declare module 'kbn' {
  var kbn : any;
  export = kbn;
}


